import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { HeadComponent } from './head.component';
import { BodyComponent } from './body.component';

@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent, HeadComponent, BodyComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }

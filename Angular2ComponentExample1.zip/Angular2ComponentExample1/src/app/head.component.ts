import { Component } from '@angular/core';

@Component({
  selector:"my-head",
  template :"<div style='background-color:lightgray;width:100%;height:100px'><h1>Header</h1><h2>Header</h2></div>",
   //styles: ['h1 { color: purple; }','h2 { color: red; }']
   styleUrls:['./head.component.css']
})
export class HeadComponent {}
import { Component } from '@angular/core';
@Component({
  selector:"my-body",
  templateUrl :'./body.component.html'
})
export class BodyComponent {
 username:String="Yogesh"
 password:String="Rajput"
}

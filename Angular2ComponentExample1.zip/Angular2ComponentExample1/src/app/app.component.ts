import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `{{name}}<my-head></my-head><br/><my-body></my-body>`,
})
export class AppComponent  { name = 'HellSkippers Private Limited'; }




